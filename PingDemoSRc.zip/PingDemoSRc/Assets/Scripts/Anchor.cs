﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Anchor : MonoBehaviour {

    public Anchor wAnchor;
    public Anchor aAnchor;
    public Anchor sAnchor;
    public Anchor dAnchor;

    // Use this for initialization
    void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}
}
