﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TickMain : MonoBehaviour {

	public void Start() {

	}


}

